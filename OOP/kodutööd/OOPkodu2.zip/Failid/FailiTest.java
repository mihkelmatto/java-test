import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;

public class FailiTest {
    public static void main(String[] args) throws Exception{
        
        Path filepath = Path.of(args[0]);
        if(! Files.isDirectory(filepath)){
            System.out.println("Faili ei leitud");
            return;
        }
        FailiVaatleja vaatleja = new FailiVaatleja();
        Files.walkFileTree(filepath, vaatleja);

        Collections.sort(vaatleja.getFailiNimed(), new NimeVõrdleja());
        for(String nimi : vaatleja.getFailiNimed()){
            System.out.println(nimi);
        }
        
    }
}

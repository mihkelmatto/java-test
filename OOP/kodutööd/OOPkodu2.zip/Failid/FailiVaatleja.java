import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class FailiVaatleja implements FileVisitor<Path>{
    private List<String> failiNimed;

    public FailiVaatleja(){
        this.failiNimed = new ArrayList<>();
    }

    public List<String> getFailiNimed(){
        return this.failiNimed;
    }

    @Override
    public FileVisitResult visitFileFailed(Path path, IOException exception){
        return FileVisitResult.CONTINUE;
    }
    @Override    
    public FileVisitResult postVisitDirectory(Path path, IOException exception){
        return FileVisitResult.CONTINUE;
    }
    @Override
    public FileVisitResult visitFile(Path path, BasicFileAttributes attributes){
        this.failiNimed.add(path.toString());
        return FileVisitResult.CONTINUE;
    }
    @Override
    public FileVisitResult preVisitDirectory(Path path, BasicFileAttributes attributes){
        return FileVisitResult.CONTINUE;
    }

}
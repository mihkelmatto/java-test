import java.util.Comparator;

public class NimeVõrdleja implements Comparator<String>{
    @Override
    public int compare(String i1, String i2){
        return i2.compareTo(i1);
    }
}

/**
 * Collection for holding Person objects.<br>
 * Provides the following guarantees:<br>
 * 1) Elements are guaranteed to be in ascending order, sorted by their ID code value.<br>
 * 2) Elements are guaranteed to have unique ID code values.<br>
 *
 * Uses an underlying array for storing the elements. <br>
 * The object guarantees to not use more than twice the required array size.<br>
 * For example, if currently 10 list are stored, then the underlying array size might range from 10 to 20, but will not be larger.
 */
public class SortedUniquePersonList {
  private Person[] list;
  private int index;  // first empty index
  
  public SortedUniquePersonList(){
    this.list = new Person[0];
    this.index = 0;
  }
  /**
   * Returns reference to object at the given index. Checks that the given index is in bounds of the underlying array, returns null if it isn't.
   * @param index Index at which the object is searched.
   * @return Person object at the given index, or null if the index is out of bounds.
   */
  public Person getElementAt(int index) {
    if(index >= this.index) return null;
    if(index < 0) return null;
    return this.list[index];
  }

  /**
   * Returns the index of the object with the given ID code. If an object with the given ID code is not present, returns -1.
   * @param idCode ID code that is searched.
   * @return Index at which the Person object with the given ID code can be found, or -1 if no such ID code is present.
   */
  public int indexOf(int idCode) {
    for(int i = 0; i<this.index; i++){
      if(this.list[i].getIdCode() == idCode){
        return i;
      }
    }
    return -1;

  }

  /**
   * Attempts to add the person to the collection, but only if no person with the same ID code is already present.<br>
   * If an element is added, it is inserted to the correct position according to their ID code. Also, the index of all subsequent elements is then increased.<br>
   * If a Person object with the same ID code is already present, does nothing.
   * @param person Person object to be added.
   * @return true if person was added to the collection, false otherwise.
   */
  public boolean add(Person person) {
    int newid = person.getIdCode();

    // exception for 0-length
    if(this.list.length == 0){
      extend();
      this.list[this.index++] = person;
      return true;
    }

    // check for existing ID
    for(int i = 0; i < this.index; i++){
      if(newid > this.list[i].getIdCode()) continue;
      if(newid == this.list[i].getIdCode()) return false; // duplicate protection
      if(this.index == this.list.length) extend(); // check length
      
      // add to the middle
      Person[] temp = new Person[this.list.length];
      int tempindex = 0;
      for(int j = 0; j<this.index; j++){
        if(j==i){
          temp[tempindex++] = person;
        }
        temp[tempindex++] = this.list[j];
      }
      this.list = temp;
      this.index = tempindex;
      return true;
    }

    
    // add to end
    if(this.index == this.list.length) extend(); // check length
    this.list[this.index++] = person;
    return true;
  }


  /**
   * Attempts to remove the person with the given ID code from the collection. Does nothing if no Person object with the given ID code is present.<br>
   * In the case of a successful removal of an object, decreases the index of all subsequent elements.
   * @param idCode ID code that is searched.
   * @return true if the person with the given ID code was removed, false otherwise.
   */
  public boolean removeElement(int idCode) {
    // find idcode
    for(int i = 0; i < this.index; i++){
      if(idCode > this.list[i].getIdCode()) continue;
      if(idCode < this.list[i].getIdCode()) return false; // idcode not found (middle)
      if(idCode == this.list[i].getIdCode()){

        // remove from end
        if(i==this.index-1){
          this.list[--this.index] = null;
          return true;
        }
          
        // remove from the middle
        Person[] temp = new Person[this.list.length];
        int tempindex = 0;
        for(int j = 0; j<this.index; j++){
          if(j==i) continue;
          temp[tempindex++] = this.list[j];
        }
        this.list = temp;
        this.index = tempindex;
        if(this.index < (int)(0.5 * this.list.length)) shrink();
        return true;
      }

    }
    // idcode not found (end)
    return false;
  }

  /**
   * Calculates and returns the size of the collection.
   * @return Number of elements in the collection.
   */
  public int size() {
    return this.index;
  }

  private void extend(){
    Person[] temp;

    if(this.list.length == 0) temp = new Person[1];
    else if(this.list.length == 1) temp = new Person[2];
    else temp = new Person[(int)(this.list.length * 1.5)];

    int tempindex = 0;
    for(Person p : this.list){
      temp[tempindex++] = p;
    }
    this.list = temp;
    this.index = tempindex;
  }

  private void shrink(){
    Person[] temp = new Person[(int)(this.list.length * 0.5)];
    int tempindex = 0;
    for(int i = 0; i < this.index; i++){
      temp[tempindex++] = this.list[i];
    }
    this.list = temp;
    this.index = tempindex;
  }
}
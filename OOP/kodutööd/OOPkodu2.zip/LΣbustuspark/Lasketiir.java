public class Lasketiir implements Lõbustus { 
    @Override
    public void lõbusta(Külastaja külastaja){
        int randomnr = (int)(Math.random() * 20);
        külastaja.lisaKirjeldus("tabasin lasketiirus " + randomnr + " sihtmärki");
    }
}

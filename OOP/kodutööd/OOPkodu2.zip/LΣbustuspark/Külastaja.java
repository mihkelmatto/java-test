import java.util.ArrayList;
import java.util.List;

public class Külastaja {
    private List<String> külastuseKirjeldused;
    private int vanus;
    private double kulud;

    public Külastaja(int vanus){
        this.külastuseKirjeldused = new ArrayList<>();
        this.vanus = vanus;
        this.kulud = 0;
    }

    public void lisaKirjeldus(String kirjeldus){
        this.külastuseKirjeldused.add(kirjeldus);
    }

    public List<String> kõikKirjeldused(){
        return this.külastuseKirjeldused;
    }

    public int getVanus(){
        return this.vanus;
    }

    public void lisaKulu(double kulu){
        this.kulud += kulu;
    }
    
    public double kuludeSumma(){
        return this.kulud;
    }
}

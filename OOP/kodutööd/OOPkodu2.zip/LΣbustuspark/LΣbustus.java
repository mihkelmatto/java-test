public interface Lõbustus {    
    void lõbusta(Külastaja külastaja);
}


import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        Vaateratas vaateratas = new Vaateratas();
        Lasketiir lasketiir = new Lasketiir();
        Kloun kloun = new Kloun("Donald");
        LõbustavKloun lõbuskloun = new LõbustavKloun(kloun);

        /* 
        1.5: Kui TasulineLõbustus delegeeriks vanusekontrolliga lasketiirule,
        siis külastaja maksaks raha olenemata sellest, kas ta vanusekontrolli läbib.
        */

        TasulineLõbustus tasulinevaateratas = new TasulineLõbustus(2.25, vaateratas);
        TasulineLõbustus tasulinelasketiir = new TasulineLõbustus(1.5, lasketiir);
        VanuseKontrollija vanusekontrollija = new VanuseKontrollija(10, tasulinelasketiir);

        ArrayList<Lõbustus> lõbustused = new ArrayList<>();
        lõbustused.add(tasulinevaateratas);
        lõbustused.add(vanusekontrollija);
        lõbustused.add(lõbuskloun);

        Lõbustuspark lõbustuspark = new Lõbustuspark(lõbustused);

        Külastaja külastaja1 = new Külastaja(9);
        Külastaja külastaja2 = new Külastaja(11);
        
        lõbustuspark.alustaSeiklust(külastaja1);
        lõbustuspark.alustaSeiklust(külastaja2);
    }
}

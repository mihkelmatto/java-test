public class Ajakiri extends Teos{

    private int aasta;

    Ajakiri(String teosekirjeldus, String teosetähis, String laenutaja, int päevadearv){
        super(teosekirjeldus, teosetähis, laenutaja, päevadearv);
        // ajakirja kirjeldus on alati "tekst/aasta,nr", seega aasta = split[1]
        String temp = this.getTeosekirjeldus().split("[/,]")[1];
        this.aasta = Integer.valueOf(temp);
    }

    @Override
    public boolean kasHoidlast(){        
        if(this.aasta <= 2000) return true;
        else return false;
    }

    @Override
    public String toString(){
        return "Tegemist on ajakirjaga. \n" + super.toString();
    }  
}

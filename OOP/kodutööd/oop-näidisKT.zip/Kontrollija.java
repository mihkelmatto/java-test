public interface Kontrollija {
    public void salvestaViivis(String nimi, String teosekirjeldus, Double viivis);   
}

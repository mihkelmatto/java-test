public class Raamat extends Teos{
    
    Raamat(String teosekirjeldus, String teosetähis, String laenutaja, int päevadearv){
        super(teosekirjeldus, teosetähis, laenutaja, päevadearv);
    }

    @Override
    public boolean kasHoidlast(){
        boolean kashoidlast;
        switch(this.getTeosetähis()){
            case "kollane" -> kashoidlast = true;
            case "sinine" -> kashoidlast = true;
            default -> kashoidlast = false;
        }
        return kashoidlast;
    }

    @Override
    public String toString(){
        return "Tegemist on raamatuga. \n" + super.toString();
    }
    
}

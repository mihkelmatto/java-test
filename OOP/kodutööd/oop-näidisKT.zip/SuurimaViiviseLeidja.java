public class SuurimaViiviseLeidja implements Kontrollija{
    Double suurimviivis;
    String svlaenutaja;
    String svkirjeldus;
    
    SuurimaViiviseLeidja(){
        this.suurimviivis = 0.0;
        this.svlaenutaja = "Suurim viivis puudub (laenutaja)";
        this.svkirjeldus = "Suurim viivis puudub (kirjeldus)";
    }

    @Override
    public void salvestaViivis(String laenutaja, String teosekirjeldus, Double viivis) {
        if(viivis > suurimviivis){
            this.suurimviivis = viivis;
            this.svlaenutaja = laenutaja;
            this.svkirjeldus = teosekirjeldus;
        }
    }

    public void saadaHoiatus(){
        System.out.printf("""
                Suurim viivis
                Laenutaja: %s
                Teose kirjeldus: %s
                """, this.svlaenutaja, this.svkirjeldus);
    }
}
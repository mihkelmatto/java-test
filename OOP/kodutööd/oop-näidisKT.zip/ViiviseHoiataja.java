import java.util.ArrayList;

public class ViiviseHoiataja implements Kontrollija{
    private double lubatudViivis;
    private ArrayList<String> hoiatatavadLaenutajad;

    ViiviseHoiataja(double lubatudViivis){
        this.lubatudViivis = lubatudViivis;
        this.hoiatatavadLaenutajad = new ArrayList<>();
    }
    
    // teosekirjeldus ei tee midagi? 
    @Override
    public void salvestaViivis(String nimi, String teosekirjeldus, Double viivis){
        if(viivis > this.lubatudViivis && 
            !this.hoiatatavadLaenutajad.contains(nimi)){

            this.hoiatatavadLaenutajad.add(nimi);
        }
    }
    
    public ArrayList<String> getHoiatatavadLaenutajad(){
        return this.hoiatatavadLaenutajad;
    }
}
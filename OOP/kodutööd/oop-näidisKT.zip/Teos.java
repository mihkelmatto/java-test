public abstract class Teos implements Comparable<Teos> {
    abstract boolean kasHoidlast();

    private String teosekirjeldus;
    private String teosetähis;
    private String laenutaja;
    private int päevadearv;

    public Teos(String teosekirjeldus, String teosetähis, String laenutaja, int päevadearv){
        this.teosekirjeldus = teosekirjeldus;
        this.teosetähis = teosetähis;
        this.laenutaja = laenutaja;
        this.päevadearv = päevadearv;
        System.out.printf("Teos loodud: \n%s", this);
    }

    public int laenutusaeg(){
        int laenutusaeg;
        switch(this.teosetähis){
            case "puudub" -> laenutusaeg = 14;
            case "roheline" -> laenutusaeg = 1;
            case "kollane" -> laenutusaeg = 30;
            case "sinine" -> laenutusaeg = 60;
            default -> laenutusaeg = 0;
        }
        return laenutusaeg;
    }

    // default?
    public double päevaneViivis(){
        double pviivis;
        switch(this.teosetähis){
            case "puudub" -> pviivis = 0.15;
            case "roheline" -> pviivis = 2.0;
            case "kollane" -> pviivis = 0.05;
            case "sinine" -> pviivis = 0.05;
            default -> pviivis = 0;
        }
        return pviivis;

    }

    public void arvutaViivis(Kontrollija kontrollija){
        int laenutusaeg = laenutusaeg();
        double pviivis = päevaneViivis();
        double kokku = 0;
        
        if(this.päevadearv > laenutusaeg){
            kokku = (päevadearv-laenutusaeg) * pviivis;
            kontrollija.salvestaViivis(this.laenutaja, this.teosekirjeldus, kokku);
        }        
    }

    @Override
    public String toString(){
        String hoidlast = (this.kasHoidlast() == true) ? "jah" : "ei";

        return String.format("""
                Teose kirjeldus: %s
                Tähis: %s
                Laenutaja: %s
                Päevade arv: %s
                Asub hoidlas: %s \n
                """, this.teosekirjeldus, this.teosetähis, this.laenutaja, this.päevadearv, hoidlast);
    }

    @Override
    public int compareTo(Teos teos){
        return this.teosekirjeldus.compareTo(teos.teosekirjeldus);
    }

    public String getTeosetähis(){
        return this.teosetähis;
    }

    public String getTeosekirjeldus(){
        return this.teosekirjeldus;
    }
}

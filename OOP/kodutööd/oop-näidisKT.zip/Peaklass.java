import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Peaklass {
    public static void main(String[] args) throws Exception {
        // teoste listi loomine ja sorteerimine
        List<Teos> teosed = loeTeosed(args[0]);
        teosed.sort(null);

        // Hoiatavate isikute leidmine
        ViiviseHoiataja hoiataja = new ViiviseHoiataja(0.2);
        for(Teos teos : teosed) teos.arvutaViivis(hoiataja);
        System.out.printf("Hoiatatavad laenutajad: \n%s \n\n", hoiataja.getHoiatatavadLaenutajad());

        // Suurima viivise leidmine
        SuurimaViiviseLeidja leidja = new SuurimaViiviseLeidja();
        for(Teos teos : teosed) teos.arvutaViivis(leidja);
        leidja.saadaHoiatus();
    }

    // faili lugemine
    public static List<Teos> loeTeosed(String path) throws Exception{
        ArrayList<Teos> teosed = new ArrayList<>();

        try(Scanner scanner = new Scanner(new File(path), "UTF-8")){
            while(scanner.hasNextLine()){
                
                // line: teosekirjeldus ("autor, nimetus" või "ajakiri/aasta, number"), teosetähis, laenutaja, päevadearv
                String[] line = scanner.nextLine().strip().split("; ");

                if(line[0].contains("/")) teosed.add(new Ajakiri(line[0], line[1], line[2], Integer.valueOf(line[3])));
                else teosed.add(new Raamat(line[0], line[1], line[2], Integer.valueOf(line[3])));
            }
        }
        catch(Exception e){
            System.out.println(e);
        }

        return teosed;
    }
}

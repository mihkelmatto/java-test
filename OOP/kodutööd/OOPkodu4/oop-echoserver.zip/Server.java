import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws Exception {
        while(true){
            ServerSocket server = null;
            Socket client = null;
            try{
                // Create server, which listens to port 1337
                server = new ServerSocket(1337);
                System.out.println("Now listening on: 1337");
        
                // Waiting for client connection (blocking)
                client = server.accept();
                System.out.println("Client connected\n");
        
                // create I/O streams
                DataInputStream in = new DataInputStream(client.getInputStream());
                DataOutputStream out = new DataOutputStream(client.getOutputStream());
                
                // client communication
                int messagecount = in.readInt();
                for(int i = 0; i<messagecount; i++){
                    String received = in.readUTF();
                    System.out.printf("Received: %s\n", received);
    
                    out.writeUTF(received);
                    System.out.printf("Response sent: %s\n\n", received);
                }
            }
            catch(Exception e){
                System.out.println(e);
            }
            finally{
                // end program
                server.close();
                client.close();
                System.out.println("Connection closed\n");
            }
        }
    }
}

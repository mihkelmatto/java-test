import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Client {
    public static void main(String[] args) throws Exception{
        String[] input = {"esimene", "teine", "kolmas"};
        args = input;
        
        Socket socket = null;
        try{
            // create a connection with the server at port 1337
            // this connection is shared with Server's "client" socket
            System.out.println("connecting to server");
            socket = new Socket("localhost", 1337);
            System.out.println("Connected\n");

            // create I/O streams
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            
            // Communication with server
            int messagecount = args.length;
            out.writeInt(messagecount);

            for(int i = 0; i<messagecount; i++){
                String tosend = args[i];
                out.writeUTF(tosend);
                System.out.printf("Sent: %s\n", tosend);

                String received = in.readUTF();
                System.out.printf("Response: %s\n\n", received);
                
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            socket.close();
            System.out.println("Connection closed");
        }
    }
}

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class Client {
    public static void main(String[] args) throws Exception{
        // String[] input = {"echo", "teine", "file", "test.txt"};
        // args = input;

        Socket socket = null;
        try{
            // create a connection with the server at port 1337
            // this connection is shared with Server's "client" socket
            System.out.println("connecting to server");
            socket = new Socket("localhost", 1337);
            System.out.println("Connected\n");

            // create I/O streams
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            
            // Communication with server
            int messagecount = args.length / 2;
            out.writeInt(messagecount);

            for(int i = 1; i<args.length; i+=2){
                String request = args[i-1];
                String value = args[i];
                sendRequest(request, value, in, out);
                getResponse(in, out);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            socket.close();
            System.out.println("Connection closed");
        }
    }
    public static void sendRequest(String requeststr, String value, DataInputStream in, DataOutputStream out)throws Exception{
        // format: int request(type), string data

        // Send request code
        int request = -1;
        if(requeststr.equals("echo")) request = 0;
        else if(requeststr.equals("file")) request = 1;
        
        out.writeInt(request);

        // Send request data
        out.writeUTF(value);
        System.out.printf("Request %s sent for value: %s\n", request, value);
    }

    public static void getResponse(DataInputStream in, DataOutputStream out) throws Exception{
        // format: int status, int datalen, string data
        // status = -1: no datalen or data
        int response = in.readInt();
        if(response == 0) receiveEcho(in, out);
        else if(response == 1) receiveFile(in, out);
        else System.out.printf("Response code: %s\n\n", response);
    }

    public static void receiveEcho(DataInputStream in, DataOutputStream out)throws Exception{
        int datalen = in.readInt();
        for(int i = 0; i<datalen; i++){
            String response = in.readUTF();
            System.out.printf("Response: %s\n\n", response);
        }      
    }

    // int datalen, String path(excluded from datalen), String data
    public static void receiveFile(DataInputStream in, DataOutputStream out)throws Exception{
        int datalen = in.readInt();
        Path path = Path.of(in.readUTF());

        ArrayList<String> filecontents = new ArrayList<>();       
        for(int i = 0; i<datalen; i++){
            filecontents.add(in.readUTF());
        }

        Files.write(path, filecontents);
        System.out.printf("File %s received\n\n", path);
    }
}

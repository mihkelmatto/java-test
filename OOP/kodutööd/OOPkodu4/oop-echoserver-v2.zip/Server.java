import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class Server {
    public static void main(String[] args) throws Exception {
        ServerSocket server = null;
        try{
            // Create server, which listens to port 1337
            server = new ServerSocket(1337);
            
            while(true){
                // Waiting for client connection (blocking)
                System.out.println("Now listening on: 1337");
                Socket client = server.accept();
                System.out.println("Client connected\n");
                new Worker(client).start();
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            server.close();
            System.out.println("Server closed");
        }
    }

    public static void processRequest(DataInputStream in, DataOutputStream out) throws Exception{
        System.out.println("Processing request");
        int request = in.readInt();

        if(request == 0)echo(in, out);
        else if (request == 1)file(in, out);
        else invalidRequest(in, out); 
    }

    public static void invalidRequest(DataInputStream in, DataOutputStream out)throws Exception{
        in.readUTF(); // void request data

        int status = -1;
        out.writeInt(status);
       
        System.out.printf("Response sent: %s\n\n", status);

    }

    public static void echo(DataInputStream in, DataOutputStream out) throws Exception{
        int status = 0;
        out.writeInt(status);

        int datalen = 1;
        out.writeInt(datalen);

        String data = in.readUTF();
        out.writeUTF(data);
        System.out.printf("Response sent: %s\n\n", data);
    }

    // Status 1: Send file as format: int status, int datalen, String path, String data 
    // Status 0: Send error message as echo: int status, int datalen, String data
    public static void file(DataInputStream in, DataOutputStream out) throws Exception{
        Path path = Path.of(in.readUTF());

        
        // create response code
        int status = 1;
        String echoresponse = "";

        if(path.isAbsolute()){
            status = 0;
            echoresponse = String.format("File path can't be absolute: %s\n", path);
        }
        else if(!Files.exists(path) || Files.isDirectory(path)){
            status = 0;
            echoresponse = String.format("File %s not found\n", path);
        }

        if(status == 0){    // error message
            out.writeInt(status);
            out.writeInt(1);
            out.writeUTF(echoresponse);     
            System.out.printf("Response sent: %s\n", echoresponse);       
        }
        else if(status == 1){ // send file
            

            ArrayList<String> filecontents = new ArrayList<>(Files.readAllLines(path));
            int datalen = filecontents.size();

            out.writeInt(status);
            out.writeInt(datalen);
            out.writeUTF(path.toString());

            for(int i = 0; i<datalen; i++){
                out.writeUTF(filecontents.get(i));
            }
            System.out.printf("File sent: %s\n", path);
        }
    }
}

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Worker extends Thread{
    Socket client;
    public Worker(Socket client){
        this.client = client;
    }

    @Override
    public void run(){
        try{
            // create I/O  streams
            DataInputStream in = new DataInputStream(this.client.getInputStream());
            DataOutputStream out = new DataOutputStream(this.client.getOutputStream());
            
            // client communication
            int messagecount = in.readInt();
            for(int i = 0; i<messagecount; i++){
                Server.processRequest(in, out);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            try{
                this.client.close();
                System.out.println("Client disconnected\n");
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }
}

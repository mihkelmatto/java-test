import java.io.File;
import java.util.concurrent.BlockingQueue;

public class Worker extends Thread {
    BlockingQueue<File> files;
    BlockingQueue<Entry> entries;

    Worker(BlockingQueue<File> files, BlockingQueue<Entry> entries){
        this.files = files;
        this.entries = entries;
    }
    @Override
    public void run(){
        try{
            while(this.files.size() > 0){
                File file = files.remove();
                Entry entry = Reader.read(file);
                entries.add(entry);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }

    }
}
import java.io.IOException;
import java.util.Scanner;
import java.io.File;
import java.math.BigInteger;


public class Reader {

    public static Entry read(File file){
        BigInteger sum = new BigInteger("0");
        BigInteger maxvalue = new BigInteger("0");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNext()){
                if(!scanner.hasNextBigInteger()){
                    scanner.next();
                    continue;
                };
                BigInteger num = scanner.nextBigInteger();
                sum = sum.add(num);
                if(maxvalue.compareTo(num) < 0) maxvalue = num;
            
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return new Entry(file, maxvalue, sum);
    }
}
import java.io.File;
import java.math.BigInteger;

public class Entry {
    File file;
    BigInteger maxvalue;
    BigInteger sum;
    public Entry(File file, BigInteger maxvalue, BigInteger sum){
        this.file = file;
        this.maxvalue = maxvalue;
        this.sum = sum;
    }
    @Override
    public String toString(){
        return String.format("File: %s\nMax value:  %s\nSum: %s\n", this.file, this.maxvalue, this.sum);
    }
}
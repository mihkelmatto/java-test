/*

Koosta paralleelarvutusprogramm, mis loeb ja töötleb paralleelselt mitut sisendfaili.

1. Käsurea argumentideks on failide relative pathid. Sisendfaile võib olla väga palju (üle 100 000).

2. Sisendfailid on utf-8 tekstifailid, millest igaüks sisaldab väga väga palju täisarve.
- arvud on eraldatud mingi arvu tühikute ja/või reavahedega
- Igas failis on vähemalt üks arv.
- Failid ja ka üksikud read võivad olla nii suured, et need ei mahu korraga mälusse ära.
- Arvud võivad olla suuremad long tüübist. Sellega hakkama saamiseks peab programm kasutama arvude hoidmiseks BigInteger klassi.

Programmi lõppedes peab main threadist ekraanile väljastama:
- Kõikide leitud arvude kogusumma
- Kõige suurema leitud üksiku arvu väärtuse ja vastava faili nime
- Kõige väiksema arvude summaga faili nime


Threadid:
- Programm peab failide töötlemiseks looma protsessorituumadega võrdse arvu threade (workerid).
- Loo üks ühine BlockingQueue, millest kõik workerid töötlemist vajavate failide nimesi võtavad.
- Loo teine ühine BlockingQueue, kuhu workerid iga faili kohta järgneva komplekti lisavad: töödeldud faili nimi, selle faili suurim üksik arv ja kõigi arvude summa.
- Programm peab töötama korrektselt ilma ühtegi synchronized plokki vajamata.
- NB! Tulemuste komplekti queue kaudu saatmisel ei tohi andmete õiged tüübid kaduma minna. Loo vajadusel tulemuste hoidmiseks eraldi klass.
- Soovi korral võib threadid+BlockingQueue asemel kasutada ExecutorService+Future.


*/
import java.io.File;
import java.math.BigInteger;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class Main {
    public static void main(String[] args) throws Exception{
        // String[] paths = {"ints.txt", "bigints.txt"};

        // create blockingqueues: files and entries
        BlockingQueue<Entry> entries = new ArrayBlockingQueue<>(args.length);
        BlockingQueue<File> files  = new ArrayBlockingQueue<>(args.length);
        for(int i = 0; i<args.length; i++){
            files.add(new File(args[i]));
        }

        process(files, entries);
        output(entries);
    }

    public static void output(BlockingQueue<Entry> entries){
        Entry firstentry = entries.element(); 

        BigInteger totalsum = new BigInteger("0");
        BigInteger maxvalue = firstentry.maxvalue;
        File maxvaluefile = firstentry.file;
        BigInteger minsum = firstentry.sum;
        File minsumfile = firstentry.file;

        for(Entry entry : entries){
            totalsum = totalsum.add(entry.sum);
            if(entry.maxvalue.compareTo(maxvalue) > 0){
                maxvalue = entry.maxvalue;
                maxvaluefile = entry.file;
            }
            if(entry.sum.compareTo(minsum) < 0){
                minsum = entry.sum;
                minsumfile = entry.file;
            }
        }
        System.out.printf("Total sum: %s \nBiggest value: %s \nat file: %s \nSmallest sum: %s \nat file: %s", totalsum, maxvalue, maxvaluefile, minsum, minsumfile);
    }

    public static void process(BlockingQueue<File> files, BlockingQueue<Entry> entries) throws Exception{
        // create workers
        Runtime runtime = Runtime.getRuntime();
        int processors = runtime.availableProcessors();
        Worker[] workers = new Worker[processors];

        for(int i = 0; i<workers.length; i++){
            workers[i] = new Worker(files, entries);
        }

        // start threads
        for(Worker worker : workers) worker.start();

        // wait for threads
        for(Worker worker : workers) worker.join(); 
    }
}
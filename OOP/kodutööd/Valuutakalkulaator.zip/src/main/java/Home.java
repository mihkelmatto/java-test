import javafx.scene.Scene;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class Home{
    private Scene scene;
    private Rates rates;

    public Home(){
        this.rates = new Rates();
        VBox root = new VBox();
        root.setSpacing(10);

        Header header = new Header(this.rates);
        Content content = new Content(this.rates);

        root.getChildren().addAll(header.getLayout(), content.getLayout());
        VBox.setVgrow(content.getLayout(), Priority.ALWAYS);

        this.scene = new Scene(root);
        this.scene.getStylesheets().add(getClass().getResource("/Global.css").toExternalForm());
    }

    public Scene getScene(){
        return this.scene;
    }
}

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class Header {
    private HBox layout;
    private Rates rates;

    public Header(Rates rates){
        this.rates = rates;
        this.layout = new HBox();
        this.layout.setSpacing(10);

        Canvas canvas = getCanvas(50);
        Label title = new Label("Valuutakalkulaator");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        ComboBox<String> dropdown = new ComboBox<>();
        dropdown.getItems().addAll(this.rates.getRates().keySet().stream().sorted().toList());
        dropdown.setValue(this.rates.getcurrency().get());
        dropdown.valueProperty().addListener((obs, oldV, newV) -> {
            this.rates.getcurrency().set(newV);
        });
        dropdown.getStyleClass().add("Dropdown");
        
        this.layout.getStyleClass().add("Header");
        this.layout.getChildren().addAll(canvas, title, spacer, dropdown);
    }

private Canvas getCanvas(int height) {
    double width = height * (200.0 / 120.0);
    double s = height / 120.0;

    Canvas canvas = new Canvas(width, height);
    GraphicsContext gc = canvas.getGraphicsContext2D();

    gc.setFill(Color.GREEN);
    gc.fillRect(20 * s, 20 * s, 160 * s, 80 * s);

    gc.setFill(Color.ORANGE);
    gc.fillOval(70 * s, 30 * s, 60 * s, 60 * s);

    gc.setFill(Color.BLACK);
    gc.setFont(Font.font("Arial", FontWeight.BOLD, 30 * s));
    gc.fillText("$", 88 * s, 70 * s);

    return canvas;
}

    public HBox getLayout(){
        return this.layout;
    }
}

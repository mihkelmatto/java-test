

import javafx.application.Application;
import javafx.stage.Stage;
/**
 * JavaFX App
 */
public class Main extends Application {

    @Override
    public void start(Stage stage) {
        Home home = new Home();

        stageSettings(stage);

        stage.setScene(home.getScene());
        stage.show();
    }

    public void stageSettings(Stage stage){
        stage.setTitle("Valuutakalkulaator");

        stage.setWidth(750);
        stage.setHeight(500);
        stage.setResizable(false);

    }


    public static void main(String[] args) {
        Application.launch(args);
    }

}
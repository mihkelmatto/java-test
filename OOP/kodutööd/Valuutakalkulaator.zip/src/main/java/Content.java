import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Content {
    private VBox layout;
    private Rates rates;
    private TextField inputText;

    public Content(Rates rates){
        this.rates = rates;
        this.layout = new VBox();
        this.layout.setSpacing(10);
        this.layout.setAlignment(javafx.geometry.Pos.CENTER);

        Label inputTitle = new Label("Soovin müüa");
        HBox input = getInputcard();

        Label outputTitle = new Label("Soovin osta");
        HBox output = getOutputCard();

        this.layout.getChildren().addAll(inputTitle, input, outputTitle, output);
        this.layout.getStyleClass().add("Content");
    }

    private HBox getInputcard(){
        HBox layout = new HBox();
        layout.setAlignment(javafx.geometry.Pos.CENTER);
        layout.setSpacing(10);
        
        this.inputText = new TextField();
        this.inputText.setPromptText("Sisesta summa: 0.0");
        this.inputText.textProperty().addListener((obs, oldV, newV) -> {
            try {
                double val = Double.parseDouble(newV);
                this.rates.getInput().set(val);
            } catch (Exception e) {
                this.rates.getInput().set(0);
            }
        });

        Button currency = new Button();
        currency.setText("EUR");
        
        layout.getStyleClass().add("Content-card");
        layout.getChildren().addAll(this.inputText, currency);
        return layout;
    }

    private HBox getOutputCard(){
        HBox layout = new HBox();
        layout.setAlignment(javafx.geometry.Pos.CENTER);
        layout.setSpacing(10);
        
        TextField text = new TextField();
        text.setEditable(false);
        text.textProperty().bind(this.rates.getResult().asString("%.3f"));
        
        Button currency = new Button();
        currency.textProperty().bind(this.rates.getcurrency());
        currency.getStyleClass().add("Clearbutton");
        currency.setOnAction(e -> {
            this.inputText.clear();
        });

        layout.getStyleClass().add("Content-card");
        layout.getChildren().addAll(text, currency);
        return layout;
    }

    public VBox getLayout(){
        return this.layout;
    }
}

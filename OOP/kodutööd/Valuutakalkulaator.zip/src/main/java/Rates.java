import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Rates {
    private HashMap<String, Double> rates;

    private StringProperty currency;
    private DoubleProperty input;
    private DoubleProperty result;

    public Rates(){
        this.rates = readRates();

        this.currency = new SimpleStringProperty(this.rates.keySet().iterator().next());
        this.input = new SimpleDoubleProperty(0);
        this.result = new SimpleDoubleProperty(0);

        this.input.addListener((obs, oldV, newV) -> calculate());
        this.currency.addListener((obs, oldV, newV) -> calculate());
    }

    private HashMap<String, Double> readRates(){
        HashMap<String, Double> rates = new HashMap<>();

        try(Scanner scanner = new Scanner(new File("src/main/resources/exchange-rates.txt"))){
            while(scanner.hasNextLine()){
                String[] line = scanner.nextLine().strip().split(";");
                String coutrycode = line[0];
                double rate = Double.valueOf(line[1]);
                rates.put(coutrycode, rate);
            }
            return rates;
        }
        catch(IOException e){
            return new HashMap<>();
        }
    }

    private void calculate() {
        Double rate = this.rates.get(this.currency.get());
        if(rate == null) return;

        this.result.set(this.input.get() * rate);
    }

    public StringProperty getcurrency() {
        return this.currency;
    }

    public DoubleProperty getInput() {
        return this.input;
    }

    public ReadOnlyDoubleProperty getResult() {
        return this.result;
    }

    public HashMap<String, Double> getRates() {
        return this.rates;
    }
}

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<String> PKuudised = new ArrayList<>();
        ArrayList<String> Foxuudised = new ArrayList<>();
        for(int i = 0; i<5; i++){
            PKuudised.add(String.format("Rahvuslik uudis %s", i));
            Foxuudised.add(String.format("Fox news %s", i));
        }

        TVStation PK = new TVStation(PKuudised);
        TVStation Foxnews = new TVStation(Foxuudised);

        PirateStation pirate = new PirateStation();
        

        TV kimJongUn = new TV("Kim Jong-un");
        PK.subscribe(kimJongUn);
        Foxnews.subscribe(kimJongUn);

        TV kimYongNam = new TV("Kim Yong-nam");
        PK.subscribe(kimYongNam);

        TV pakPongJu = new TV("Pak Pong-ju");
        pirate.subscribe(pakPongJu);


        PK.subscribe(pirate);
        Foxnews.subscribe(pirate);

        PK.sendNews();
        Foxnews.sendNews();
    }
}

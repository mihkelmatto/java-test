class TV implements BroadcastListener {
    private final String owner;

    public TV(String owner) {
        this.owner = owner;
    }

    @Override
    public void listen(String message) {
        System.out.printf("%s: %s\n", this.owner, message);
    }
}
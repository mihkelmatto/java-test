class PirateStation extends Broadcaster implements BroadcastListener{
    @Override
    public void listen(String message){
        broadcast(message);
    }
}

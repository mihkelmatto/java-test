import java.util.List;
import java.util.Random;

public class TVStation extends Broadcaster{
    private List<String> news;
    private Random random;

    public TVStation(List<String> news){
        this.news = news;
        this.random = new Random();
    }

    public void sendNews(){
        if(news.isEmpty()) return;
        broadcast(news.get(random.nextInt(news.size())));
    }
}

import java.util.ArrayList;
import java.util.List;

public class Broadcaster {
    private List<BroadcastListener> listeners;

    public Broadcaster(){
        this.listeners = new ArrayList<>();
    }

    public void subscribe(BroadcastListener listener){
        this.listeners.add(listener);
    }

    public void broadcast(String content){
        for(BroadcastListener listener : this.listeners){
            listener.listen(content);
        }
    }
}

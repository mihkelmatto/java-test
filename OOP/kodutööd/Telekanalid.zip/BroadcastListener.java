public interface BroadcastListener {
    public void listen(String content);
}
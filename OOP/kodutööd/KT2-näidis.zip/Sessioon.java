import java.util.ArrayList;
import java.util.HashMap;

public class Sessioon {
    private ArrayList<Arvuti> kiirtood;
    private ArrayList<Arvuti> tavatood;
    private ArrayList<Arvuti> tehtud;
    
    public Sessioon(ArrayList<Arvuti> arvutid){
        this.kiirtood = new ArrayList<>();
        this.tavatood = new ArrayList<>();
        this.tehtud = new ArrayList<>();

        for(Arvuti a : arvutid){
            if(a.onKiirtöö()) this.kiirtood.add(a);
            else this.tavatood.add(a);
        }
    }
    public String getKokkuvote(){
        double kaive = 0;
        for(Arvuti a : this.tehtud) kaive += a.getArveSumma();

        // loeb kokku, mitu arvutit igast firmast on parandatud
        HashMap<String, Integer> hParandatud = new HashMap<>();
        for(Arvuti a : this.tehtud){
            String tootja = a.getTootja();
            int kogus = 1;
            if(hParandatud.keySet().contains(tootja)) kogus += hParandatud.get(tootja);

            hParandatud.put(tootja, kogus);
        }

        // Stringi ehitamine
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("""
                Sessiooni kokkuvõte:
                Teenitud raha: %s €
                """, kaive));

        for(String s : hParandatud.keySet()){
            sb.append(String.format("%s: %stk\n", s, hParandatud.get(s)));
        }
        sb.append(String.format("Ootele jäi %s arvuti(t).\n", this.kiirtood.size() + this.tavatood.size()));

        return sb.toString();
    }

    public void lisaArvuti(Arvuti arvuti){
        if(arvuti.onKiirtöö()) this.kiirtood.add(arvuti);
        else this.tavatood.add(arvuti);
    }

    public Arvuti getArvuti(){
        if(kiirtood.size() > 0) return kiirtood.get(0);
        else if(tavatood.size() > 0) return tavatood.get(0);
        else return null;
    }

    public void parandaArvuti(Arvuti arvuti, double tasu){
        arvuti.setArvesumma(tasu);
        
        tehtud.add(arvuti);

        if(kiirtood.contains(arvuti)) kiirtood.remove(arvuti);
        else tavatood.remove(arvuti);
    }

    public ArrayList<Arvuti> getKiirtood(){
        return this.kiirtood;
    }

    public ArrayList<Arvuti> getTavatood(){
        return this.tavatood;
    }

    public ArrayList<Arvuti> getTehtud(){
        return this.tehtud;
    }
}

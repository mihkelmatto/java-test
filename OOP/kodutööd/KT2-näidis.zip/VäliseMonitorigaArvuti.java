import java.time.LocalDateTime;

public class VäliseMonitorigaArvuti extends Arvuti{

    public VäliseMonitorigaArvuti(String tootja, boolean onKiirtöö, LocalDateTime registreerimiseAeg){
        super(tootja, onKiirtöö, registreerimiseAeg);
    }

    @Override
    public String toString(){
        String[] arvuti = super.toString().split("@");
        return String.format("%s;monitoriga@%s", arvuti[0], arvuti[1]);
    }

    @Override
    public double arvutaArveSumma(double baashind){
        return super.arvutaArveSumma(baashind) + 1;
    }
}

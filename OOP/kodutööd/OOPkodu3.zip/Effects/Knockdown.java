package Effects;

import Characters.Dude;

public class Knockdown implements Effect{
    public static int cost = 20;
    int duration;

    public Knockdown(){
        this.duration = 1;
    }

    @Override
    public String toString(){
        return "Knockdown";
    }

    @Override
    public void onHit(Dude effectTarget){
        effectTarget.actionpoints = 0;
        System.out.printf("%s mana reduced to 0\n", effectTarget);
    }

    @Override
    public void onTurnStart(Dude effectTarget){

    }

    @Override
    public void onTurnEnd(Dude effectTarget){
        this.duration--;
    }

    @Override
    public int requiredActionPoints(){
        return cost;
    }

    @Override
    public boolean isExpired(){
        if(this.duration > 0) return false;
        else return true;
    }
}

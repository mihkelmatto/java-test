package Effects;

import Characters.Dude;

public class Firebolt implements Effect {
    public static int cost = 1;
    static int damage = 35;
    int duration;

    public Firebolt(){
        this.duration = 1;
    }

    @Override
    public String toString(){
        return "Firebolt";
    }

    @Override
    public void onHit(Dude effectTarget){

    }

    @Override
    public void onTurnStart(Dude effectTarget){

    }

    @Override
    public void onTurnEnd(Dude effectTarget){
        effectTarget.health -= damage;
        System.out.printf("%s takes %s damage (%s remaining)\n", effectTarget, damage, effectTarget.health);
        this.duration--;
    }

    @Override
    public int requiredActionPoints(){
        return cost;
    }

    @Override
    public boolean isExpired(){
        if(this.duration > 0) return false;
        else return true;
    }
}

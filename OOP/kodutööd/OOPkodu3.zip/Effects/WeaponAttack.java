package Effects;

import Characters.Dude;

public class WeaponAttack implements Effect {
    public static int cost = 1;
    static int damage = 20;
    int duration;

    public WeaponAttack(){
        this.duration = 1;
    }

    @Override
    public String toString(){
        return "WeaponAttack";
    }    

    @Override
    public void onHit(Dude effectTarget){
        effectTarget.health -= damage;
        System.out.printf("%s takes %s damage (%s remaining)\n", effectTarget, damage, effectTarget.health);
    }

    @Override
    public void onTurnStart(Dude effectTarget){
    
    }

    @Override
    public void onTurnEnd(Dude effectTarget){
        this.duration--;
    }

    @Override
    public int requiredActionPoints(){
        return cost;
    }

    @Override
    public boolean isExpired(){
        if(this.duration > 0) return false;
        else return true;
    }
}

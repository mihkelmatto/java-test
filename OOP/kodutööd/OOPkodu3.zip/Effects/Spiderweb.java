package Effects;

import Characters.Dude;

public class Spiderweb implements Effect {
    public static int cost = 10;
    static int strength = 3;
    int duration;

    public Spiderweb(){
        this.duration = 2;
    }

    @Override
    public String toString(){
        return "Spiderweb";
    }

    @Override
    public void onHit(Dude effectTarget){

    }

    @Override
    public void onTurnStart(Dude effectTarget){

    }

    @Override
    public void onTurnEnd(Dude effectTarget){
        effectTarget.actionpoints = Math.max(0, effectTarget.actionpoints - strength);
        this.duration--;
        System.out.printf("%s mana is reduced by %s (%s remaining)\n", effectTarget, strength, effectTarget.actionpoints);
    }

    @Override
    public int requiredActionPoints(){
        return cost;
    }   

    @Override
    public boolean isExpired(){
        if(this.duration > 0) return false;
        else return true;
    }
}

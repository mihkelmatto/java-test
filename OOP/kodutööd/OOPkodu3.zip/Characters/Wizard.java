package Characters;

import Effects.*;

public class Wizard extends Dude{
    public Wizard(int accuracy, int armor, int health, int actionpoints, int actionregen){
        super(accuracy, armor, health, actionpoints, actionregen);
    }
    @Override
    public String toString(){
        return "Wizard";
    }

    @Override
    public Effect attack(){
        if(this.actionpoints >= Spiderweb.cost) return new Spiderweb();
        if(this.actionpoints >= Firebolt.cost) return new Firebolt();
        return null;
    }
}
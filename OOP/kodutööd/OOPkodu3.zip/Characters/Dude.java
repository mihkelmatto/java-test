package Characters;

import java.util.ArrayList;
import java.util.List;

import Effects.Effect;

public abstract class Dude{
    public int health;
    public int actionpoints;
    int accuracy;
    int armor;
    int actionregen;
    private List<Effect> activeeffects;

    public abstract String toString();
    public abstract Effect attack();

    public Dude(int accuracy, int armor, int health, int actionpoints, int actionregen){
        this.accuracy = accuracy;
        this.armor = armor;
        this.health = health;
        this.actionpoints = actionpoints;
        this.actionregen = actionregen;
        this.activeeffects = new ArrayList<>();
    }

    public boolean isAlive(){
        if(this.health > 0) return true;
        else return false;
    }

    public void takeTurn(Dude attackTarget){
        // start turn
        for(Effect effect : this.activeeffects){
            effect.onTurnStart(this);
        }

        // attack
        Effect attack = this.attack();
        int d20 = (int)(Math.random() * 20) + 1;
        if (attack != null && d20 + this.accuracy >= attackTarget.armor) {
            System.out.printf("%s casts %s \n", this, attack);
            this.actionpoints -= attack.requiredActionPoints();
            attack.onHit(attackTarget);
            attackTarget.activeeffects.add(attack);
        }
        else System.out.println(this + " missed");

        // end turn
        for(int i = this.activeeffects.size()-1; i>=0; i--){
            Effect effect = activeeffects.get(i);
            effect.onTurnEnd(this);
            if(effect.isExpired()) this.activeeffects.remove(i);
        }
        System.out.println("");
        this.actionpoints += this.actionregen;
    }
}
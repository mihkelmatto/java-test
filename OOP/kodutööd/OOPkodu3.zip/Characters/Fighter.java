package Characters;

import Effects.*;

public class Fighter extends Dude{
    public Fighter(int accuracy, int armor, int health, int actionpoints, int actionregen){
        super(accuracy, armor, health, actionpoints, actionregen);
    }

    @Override
    public String toString(){
        return "Fighter";
    }

    @Override
    public Effect attack(){
        if(this.actionpoints >= Knockdown.cost)return new Knockdown();
        if(this.actionpoints >= WeaponAttack.cost) return new WeaponAttack();
        return null;
    }
}

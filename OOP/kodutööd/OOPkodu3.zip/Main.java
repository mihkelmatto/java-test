import Characters.*;

public class Main {
    public static void main(String[] args) {
        Wizard wizard = new Wizard(18, 20, 100, 2, 3);
        Fighter fighter = new Fighter(19, 30, 100, 1, 2);

        while(true){
            wizard.takeTurn(fighter);
            if(!fighter.isAlive()){
                System.out.println("Fighter died");
                break;
            }
            sleep(1);
            
            fighter.takeTurn(wizard);
            if(!wizard.isAlive()){
                System.out.println("Wizard died");
                break;
            }
            sleep(1);
        }
    }

    static void sleep(int sec){
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}


public class Suusad extends Spordivahend{

    Suusad(String tootja, int pikkus, int kasutuskordi){
        super(tootja, pikkus, kasutuskordi);
    }

    @Override
    public double maksKiirus(){
        return this.getPikkus() * 0.6;
    }

    @Override
    public String toString(){
        return String.format("""
                Suusad
                %s
                """, super.toString());
    }
}


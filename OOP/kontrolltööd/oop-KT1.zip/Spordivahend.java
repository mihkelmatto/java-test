public abstract class Spordivahend implements Comparable<Spordivahend>{
    private String tootja;
    private int pikkus;
    private int kasutuskordi;

    abstract double maksKiirus();

    public Spordivahend(String tootja, int pikkus, int kasutuskordi){
        this.tootja = tootja;
        this.pikkus = pikkus;
        this.kasutuskordi = kasutuskordi;
    }

    public boolean kasVajabHooldust(){
        if(kasutuskordi >= 3) return true;
        else return false;
    }

    /*
    "Suurendab kasutuskordade arvu, kui vahend ei vaja hooldust"
    eeldan, et peaks olema +1
    */
    public void laena(){
        if(!kasVajabHooldust()) this.kasutuskordi++;
    }

    public void hooldus(){
        this.kasutuskordi = 0;
    }

    @Override
    public String toString(){
        return String.format("""
                Tootja: %s
                Pikkus: %s
                Maksimaalne kiirus: %s
                Kasutuskordade arv: %s
                """, this.tootja, this.pikkus, this.maksKiirus(), this.kasutuskordi);
    }

    @Override
    public int compareTo(Spordivahend spordivahend){
        if(this.maksKiirus() > spordivahend.maksKiirus()) return 1;
        else if(this.maksKiirus() < spordivahend.maksKiirus()) return -1;
        else return 0;
    }

    /*
    private String tootja;
    private int pikkus;
    private int kasutuskordi;
    */

    public int getPikkus(){
        return this.pikkus;
    }

}
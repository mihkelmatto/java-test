public class Lumelaud extends Spordivahend{
    private double laius;

    Lumelaud(String tootja, int pikkus, int kasutuskordi, double laius){
        super(tootja, pikkus, kasutuskordi);
        this.laius = laius;
    }

    @Override
    public double maksKiirus(){
        return this.getPikkus()*0.5 - this.laius*0.3;
    }

    @Override
    public String toString(){
        return String.format("""
                Lumelaud
                Laua laius: %s
                %s
                """, this.laius, super.toString());
    }
}

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Peaklass {
    public static void main(String[] args) throws Exception{
        List<Spordivahend> spordivahendid = loeVahendid("talispordivahendid.txt");
        Collections.sort(spordivahendid);

        System.out.println("/// Vahendid: \n");
        for(Spordivahend spordivahend : spordivahendid) System.out.print(spordivahend);
        System.out.println("");

        Laenutus laenutus = new Laenutus("Munakas");
        laenutus.setSpordivahendid(spordivahendid); // setteriga, sest antud programmis on hetkel garanteeritud tühi laenutus.spordivahendid

        System.out.println("/// Laenutused: \n");
        for(int i = 0; i<20; i++){
            Collections.shuffle(spordivahendid);
            spordivahendid.get(0).laena();
            System.out.printf("Laenutatud spordivahend: \n%s", spordivahendid.get(0));
        }

        System.out.println("/// Hooldus: \n");
        System.out.println(laenutus);
        for(Spordivahend spordivahend : spordivahendid) spordivahend.hooldus();
        System.out.println(laenutus);
    }


    // kasutuskordade arv: 0
    private static List<Spordivahend> loeVahendid(String path) throws Exception{
        ArrayList<Spordivahend> spordivahendid = new ArrayList<>();

        try(Scanner scanner = new Scanner(new File(path), "UTF-8")){
            while(scanner.hasNextLine()){
                String[] rida = scanner.nextLine().strip().split(";");

                // Lumelaud(String tootja, int pikkus, int kasutuskordi, double laius)
                if(rida[0].equals("lumelaud")){
                    spordivahendid.add(new Lumelaud(rida[1], Integer.valueOf(rida[2]), 0, Double.valueOf(rida[3])));
                }

                // Suusad(String tootja, int pikkus, int kasutuskordi)
                else if(rida[0].equals("suusad")){
                    spordivahendid.add(new Suusad(rida[1], Integer.valueOf(rida[2]), 0));
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }



        return spordivahendid;
    }
}

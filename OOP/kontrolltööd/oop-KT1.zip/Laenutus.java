import java.util.ArrayList;
import java.util.List;

public class Laenutus {
    private String firmaNimi;
    private List<Spordivahend> spordivahendid;

    public Laenutus(String firmaNimi){
        this.firmaNimi = firmaNimi;
        this.spordivahendid = new ArrayList<Spordivahend>();
        // spordivahendid on vaja mujal teha?
    }

    public void lisaVahend(Spordivahend spordivahend){
        this.spordivahendid.add(spordivahend);
    }

    public void eemaldaVahend(Spordivahend spordivahend){
        this.spordivahendid.remove(spordivahend);
    }

    public List<Spordivahend> laenutamiseksSobivad(){
        ArrayList<Spordivahend> sobivad = new ArrayList<>();

        for(Spordivahend spordivahend : this.spordivahendid){
            if(!spordivahend.kasVajabHooldust()) sobivad.add(spordivahend);
        }

        return sobivad;
    }

    public void teostaHooldused(){
        System.out.println("Hoolduste teostamine: ");

        for(Spordivahend spordivahend : this.spordivahendid){
            if(spordivahend.kasVajabHooldust()){
                spordivahend.hooldus();
                System.out.println(spordivahend);
            }
        }
    }

    @Override
    public String toString(){
        return String.format("""
                Firma nimi: %s
                Spordivahendite arv: %s
                Laenutamiseks sobivate vahendite arv: %s
                """, this.firmaNimi, this.spordivahendid.size(), this.laenutamiseksSobivad().size());
    }

    public List<Spordivahend> getSpordivahendid(){
        return this.spordivahendid;
    }

    public void setSpordivahendid(List<Spordivahend> spordivahendid){
        this.spordivahendid = spordivahendid;
    }
}
